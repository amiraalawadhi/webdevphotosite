from django import forms
from albums.models import Albums
...

class AlbumForm(forms.Form):
    name=forms.CharField(max_length=100)
    #author=forms.CharField(max_length=100)
    image=forms.FileField()
    #image=forms.CharField(max_length=100)

class PhotosForm(forms.Form):
    name=forms.CharField(max_length=100)
    location=forms.CharField(max_length=100)
    caption=forms.CharField(max_length=100)
    image=forms.FileField()

class CommentForm(forms.Form):

    body = forms.CharField(widget=forms.Textarea(
    attrs={
    "class": "form-control",
    "placeholder": "Leave a comment"
    }
    ))
