from django.db import models
from djongo import models
from django import forms

class Albums(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=100)
    author=models.CharField(max_length=100)
    image=models.CharField(max_length=100)


class Photos(models.Model):
    name=models.TextField()
    album_name=models.CharField(max_length=100)
    location=models.TextField()
    caption=models.TextField()
    image=models.CharField(max_length=100)

class Comment(models.Model):
    author = models.CharField(max_length=100)
    body = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    item = models.ForeignKey('Photos', on_delete=models.CASCADE)
