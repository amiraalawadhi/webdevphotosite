from django.urls import include,path
from albums import views

app_name="albums"
urlpatterns = [
#path('photos/<int:id>/', views.photos_list, name="photos_list"),
path('', views.albums_list,name="albums_list"),
path('photos/<int:id>/', views.photos_list, name="photos_list"),
path('photosdetails/<int:id>/', views.photos_details, name="photos_details"),
path('addalbum/', views.add_album, name='add_album'),
path('addphotos/<int:id>/', views.add_photos, name="add_photos"),
]
