from django.shortcuts import render
from django.http import HttpResponse
from albums.models import Albums,Photos,Comment
from albums.forms import CommentForm,AlbumForm,PhotosForm
from django.contrib.auth.decorators import login_required
from albums.functions import handle_uploaded_file
from django.shortcuts import get_object_or_404

def albums_list(request):
    albums_objects = Albums.objects.all()
    #return HttpResponse("a HTML page should be returned")
    return render(request, 'albums.html', {'albums_objects':albums_objects})

def photos_list(request, id):
    photos_items = Albums.objects.get(id=id)
    allPhotos = Photos.objects.filter(album_name=photos_items.name)
    return render(request, 'photos.html', {'photos_items':photos_items, "allPhotos":allPhotos})


@login_required
def photos_details(request, id):
    photos_details = Photos.objects.get(id=id)
    form = CommentForm()
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = Comment(
                author= request.user.username,
                body=form.cleaned_data["body"],
                item= photos_details
            )
            comment.save()



    comments = Comment.objects.filter(item=id)
    context = {
        "photos_details": photos_details,
        "comments": comments,
        "form": form
    }
    return render(request, 'photos_details.html', context)

def add_album(request):
    if request.method == "POST":
        myForm = AlbumForm(request.POST, request.FILES)
        if myForm.is_valid():
            handle_uploaded_file(request.FILES['image'])
            name = myForm.cleaned_data["name"]
            author_first = request.user.first_name
            author_last = request.user.last_name
            author = "{0} {1}".format(author_first,author_last)
            imageFileName = request.FILES['image'].name
            imagePath = '\Albums\img\{0}'.format(imageFileName)

            albumObj = Albums(name=name,author=author,image=imagePath)
            albumObj.save()
            return render(request, 'added.html')


    else:
        myForm = AlbumForm()
    return render(request, "add_album.html", {"myForm": myForm})

def add_photos(request,id):
    photos_items = Albums.objects.get(id=id)
    if request.method == "POST":
        myForm = PhotosForm(request.POST, request.FILES)
        if myForm.is_valid():
            handle_uploaded_file(request.FILES['image'])
            name = myForm.cleaned_data["name"]
            album_name = photos_items.name
            location = myForm.cleaned_data["location"]
            caption = myForm.cleaned_data["caption"]
            imageFileName = request.FILES['image'].name
            imagePath = '\Albums\img\{0}'.format(imageFileName)
            photos1 = Photos(name=name,album_name=album_name,location=location,caption=caption,image=imagePath)
            photos1.save()
            return render(request, 'added.html')

    else:
        myForm = PhotosForm()
    return render(request, "add_photos.html", {"myForm": myForm})
